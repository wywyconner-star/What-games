export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/ai') {
      return handleAi(request, env);
    }
    if (url.pathname === '/api/health') {
      return json({ ok: true, ai: Boolean(env.OPENAI_API_KEY) });
    }
    return env.ASSETS.fetch(request);
  },
};

const MODELS = ['gpt-4o-mini', 'gpt-4.1-mini'];
const RATE_LIMIT = 25;
const WINDOW_MS = 60 * 60 * 1000;
// In-memory only: resets when the Worker isolate recycles. Good enough as a
// spend guard, not a security boundary.
const buckets = new Map();

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    },
  });
}

function sameOrigin(request, url) {
  const origin = request.headers.get('origin');
  if (!origin) return true; // non-browser client
  try {
    return new URL(origin).host === url.host;
  } catch {
    return false;
  }
}

function rateLimited(ip) {
  const now = Date.now();
  const entry = buckets.get(ip);
  if (!entry || now > entry.reset) {
    buckets.set(ip, { count: 1, reset: now + WINDOW_MS });
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT;
}

function sanitize(messages) {
  if (!Array.isArray(messages)) return null;
  const cleaned = messages
    .filter(
      (m) =>
        m &&
        typeof m.content === 'string' &&
        ['system', 'user', 'assistant'].includes(m.role),
    )
    .slice(-30)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) }));

  const total = cleaned.reduce((sum, m) => sum + m.content.length, 0);
  if (!cleaned.length || total > 24000) return null;
  return cleaned;
}

async function handleAi(request, env) {
  const url = new URL(request.url);
  if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  if (!sameOrigin(request, url)) return json({ error: 'forbidden_origin' }, 403);

  const ip = request.headers.get('cf-connecting-ip') || 'local';
  if (rateLimited(ip)) {
    return json(
      { error: 'rate_limited', message: 'Too many messages this hour. Try again later.' },
      429,
    );
  }

  if (!env.OPENAI_API_KEY) {
    return json(
      {
        error: 'missing_key',
        message:
          'No OPENAI_API_KEY is configured for this deployment. Add it in project secrets and redeploy.',
      },
      503,
    );
  }

  let payload;
  try {
    payload = await request.json();
  } catch {
    return json({ error: 'bad_json' }, 400);
  }

  const messages = sanitize(payload?.messages);
  if (!messages) return json({ error: 'bad_messages' }, 400);

  const model = MODELS.includes(payload?.model) ? payload.model : MODELS[0];
  const base = (env.AI_BASE_URL || 'https://freebuff.com/api/v1/paid').replace(/\/+$/, '');

  try {
    const upstream = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({ model, messages, temperature: 0.6, max_tokens: 900 }),
    });

    const text = await upstream.text();
    if (!upstream.ok) {
      return json(
        {
          error: 'upstream_error',
          status: upstream.status,
          message: 'The model provider rejected the request. Check the API key and its balance.',
        },
        502,
      );
    }
    return new Response(text, {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      },
    });
  } catch (err) {
    return json({ error: 'network_error', message: 'Could not reach the model provider.' }, 502);
  }
}
