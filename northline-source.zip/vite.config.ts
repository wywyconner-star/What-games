import { defineConfig, loadEnv, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * In production the AI endpoint is served by worker/index.js.
 * In `vite dev` there is no Worker, so this middleware plays the same role.
 */
function devAiApi(env: Record<string, string>): Plugin {
  return {
    name: 'northline-dev-ai-api',
    configureServer(server) {
      server.middlewares.use('/api/ai', (req, res) => {
        const send = (code: number, obj: unknown) => {
          res.statusCode = code;
          res.setHeader('content-type', 'application/json');
          res.setHeader('cache-control', 'no-store');
          res.end(JSON.stringify(obj));
        };

        if (req.method !== 'POST') return send(405, { error: 'method_not_allowed' });

        let body = '';
        req.on('data', (chunk) => {
          body += chunk;
          if (body.length > 120_000) req.destroy();
        });
        req.on('end', async () => {
          const key = env.OPENAI_API_KEY || process.env.OPENAI_API_KEY;
          if (!key) {
            return send(503, {
              error: 'missing_key',
              message:
                'OPENAI_API_KEY is not set. Add it to .env (create one at freebuff.com/account/api).',
            });
          }
          try {
            const parsed = JSON.parse(body || '{}');
            const base = (env.AI_BASE_URL || 'https://freebuff.com/api/v1/paid').replace(/\/+$/, '');
            const upstream = await fetch(`${base}/chat/completions`, {
              method: 'POST',
              headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
              body: JSON.stringify({
                model: 'gpt-4o-mini',
                temperature: 0.6,
                messages: parsed.messages,
              }),
            });
            const text = await upstream.text();
            res.statusCode = upstream.status;
            res.setHeader('content-type', 'application/json');
            res.setHeader('cache-control', 'no-store');
            res.end(text);
          } catch (err) {
            send(502, { error: 'upstream_error', message: String(err) });
          }
        });
      });
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    plugins: [react(), devAiApi(env)],
    server: { host: true, port: 3000 },
    build: { outDir: 'dist', sourcemap: false },
  };
});
