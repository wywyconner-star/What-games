# Northline Learning

A school-portal-looking site with a private student hub behind it: a browser tab,
six board/card games, a study assistant, tab cloaking and a panic key.

## Using it

1. The front page looks like a standards-aligned learning portal (IXL-ish).
2. Type `1234` into the search box and press **Search** — or click **Sign in**.
3. Enter the access key **5656**. The hub opens for the rest of the browser session.

- **Home** — paste a link and it opens in an embedded frame, with pins and quick links.
- **Games** — Tic-Tac-Toe, Connect Four, Checkers, Reversi, 2048, Go Fish.
- **AI** — study assistant backed by `/api/ai` (needs `OPENAI_API_KEY`).
- **Settings** — tab title/favicon cloaking, panic key, display name, theme.
- **Credits** — your name, Freebuff link and a download of this source.

**Panic** (`Esc` by default) drops you straight back to the portal without adding a
history entry. Change it in Settings.

## Run locally

```bash
npm install
npm run dev          # http://localhost:3000
```

To make the AI tab work locally, copy `.env.example` to `.env` and add your key:

```
OPENAI_API_KEY=...   # https://freebuff.com/account/api
```

## Build

```bash
npm run build        # writes dist/ and public/source.zip
```

`npm run build` also regenerates `public/source.zip`, which is what the
**Download source code** button serves.

## Deploy (Cloudflare Workers / Sites)

`deploy.manifest.json` points at `worker/index.js` for `/api/ai` and serves the
built `dist/` folder as static assets. Deploy the manifest after building, then
set `OPENAI_API_KEY` as a project secret if you want the AI tab live.

## Structure

```
src/components/   portal, passcode gate, app shell
src/tabs/         Home, Games, AI, Settings, Credits
src/games/        the six games
src/lib/store.tsx settings, cloaking, panic key
worker/index.js   static assets + AI proxy route
scripts/          source.zip builder
```

## Notes

- Passcode checking happens in the browser, so it is a curtain rather than real
  access control. Anything genuinely private belongs on the server.
- Pinned pages, settings and your name live in `localStorage`; the unlock flag
  lives in `sessionStorage`.
- Some sites refuse to render inside a frame (`X-Frame-Options` / CSP). The Home
  tab explains this and offers "Open in new tab".
