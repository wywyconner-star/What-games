import { useEffect, useRef, useState } from 'react';

type Pin = { label: string; url: string };

const QUICK: Pin[] = [
  { label: 'Desmos', url: 'https://www.desmos.com/calculator' },
  { label: 'Wikipedia', url: 'https://en.m.wikipedia.org' },
  { label: 'Photopea', url: 'https://www.photopea.com' },
  { label: 'wasm.rip', url: 'https://wasm.rip' },
  { label: 'Khan Academy', url: 'https://www.khanacademy.org' },
  { label: 'Mathway', url: 'https://www.mathway.com' },
];

const PIN_KEY = 'northline.pins.v1';

function loadPins(): Pin[] {
  try {
    const raw = localStorage.getItem(PIN_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Pin[];
    return Array.isArray(parsed) ? parsed.slice(0, 12) : [];
  } catch {
    return [];
  }
}

/** Turn whatever the user typed into a safe http(s) URL, or a search. */
function toUrl(raw: string): string {
  const text = raw.trim();
  if (!text) return '';
  if (/^https?:\/\//i.test(text)) return text;
  const looksLikeDomain = /^[\w-]+(\.[\w-]+)+([/?#].*)?$/.test(text) && !/\s/.test(text);
  if (looksLikeDomain) return `https://${text}`;
  return `https://duckduckgo.com/?q=${encodeURIComponent(text)}`;
}

function pretty(url: string): string {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, '') + (parsed.pathname === '/' ? '' : parsed.pathname);
  } catch {
    return url;
  }
}

export default function Home() {
  const [input, setInput] = useState('');
  const [active, setActive] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const [pins, setPins] = useState<Pin[]>(() => loadPins());
  const [toast, setToast] = useState('');
  const frameRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(PIN_KEY, JSON.stringify(pins));
    } catch {
      /* ignore */
    }
  }, [pins]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const go = (raw: string) => {
    const url = toUrl(raw);
    if (!url) return;
    setActive(url);
    setInput(url);
    setReloadKey((k) => k + 1);
  };

  const pinCurrent = () => {
    if (!active) {
      setToast('Open a page first.');
      return;
    }
    if (pins.some((p) => p.url === active)) {
      setToast('Already pinned.');
      return;
    }
    setPins((prev) => [{ label: pretty(active), url: active }, ...prev].slice(0, 12));
    setToast('Pinned.');
  };

  return (
    <div className="home">
      <form
        className="browser-bar"
        onSubmit={(e) => {
          e.preventDefault();
          go(input);
        }}
      >
        <div className="dots" aria-hidden="true">
          <i />
          <i />
          <i />
        </div>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste a link or search the web…"
          aria-label="Address"
          spellCheck={false}
        />
        <button type="submit" className="btn btn-primary">
          Open
        </button>
      </form>

      <div className="browser-actions">
        <button
          type="button"
          className="chip"
          onClick={() => setReloadKey((k) => k + 1)}
          disabled={!active}
        >
          Reload
        </button>
        <button type="button" className="chip" onClick={pinCurrent}>
          Pin this page
        </button>
        {active && (
          <a className="chip" href={active} target="_blank" rel="noreferrer">
            Open in new tab
          </a>
        )}
        {active && (
          <span className="url-label">{pretty(active)}</span>
        )}
      </div>

      <div className="frame-wrap">
        {active ? (
          <iframe
            key={reloadKey}
            ref={frameRef}
            className="frame"
            src={active}
            title="Browsing frame"
            referrerPolicy="no-referrer"
            allow="fullscreen; clipboard-write; gamepad; autoplay"
          />
        ) : (
          <div className="frame-empty">
            <div className="frame-empty-inner">
              <span className="frame-empty-icon">↗</span>
              <h2>Nothing open yet</h2>
              <p>Type a site above, or start with one of these.</p>
              <div className="quick-grid">
                {QUICK.map((q) => (
                  <button
                    key={q.label}
                    type="button"
                    className="quick-card"
                    onClick={() => go(q.url)}
                  >
                    <strong>{q.label}</strong>
                    <small>{pretty(q.url)}</small>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <p className="frame-note">
        Some sites refuse to load inside a frame (they send an <code>X-Frame-Options</code> header).
        If the panel stays blank, use <strong>Open in new tab</strong>.
      </p>

      {pins.length > 0 && (
        <section className="pins">
          <div className="pins-head">
            <h3>Pinned</h3>
            <button
              type="button"
              className="chip"
              onClick={() => {
                setPins([]);
                setToast('Cleared pins.');
              }}
            >
              Clear
            </button>
          </div>
          <div className="pin-list">
            {pins.map((pin) => (
              <div key={pin.url} className="pin">
                <button type="button" className="pin-open" onClick={() => go(pin.url)}>
                  {pin.label}
                </button>
                <button
                  type="button"
                  className="pin-x"
                  aria-label={`Remove ${pin.label}`}
                  onClick={() => setPins((prev) => prev.filter((p) => p.url !== pin.url))}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
