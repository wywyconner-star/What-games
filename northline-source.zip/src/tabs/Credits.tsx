import { useSettings } from '../lib/store';

export default function Credits() {
  const { settings } = useSettings();
  const name = settings.ownerName.trim() || 'Your name';

  return (
    <div className="credits">
      <section className="credit-hero">
        <span className="credit-kicker">Built by</span>
        <h2>{name}</h2>
        <p>
          Site, games, cloaking and the study assistant were put together in one session with
          <strong> Buffy</strong>, the coding agent from Freebuff.
        </p>
        <div className="credit-actions">
          <a className="btn btn-primary" href="https://freebuff.com" target="_blank" rel="noreferrer">
            Freebuff.com
          </a>
          <a className="btn btn-ghost" href="/source.zip" download="northline-source.zip">
            Download source code
          </a>
        </div>
      </section>

      <div className="credit-grid">
        <article className="panel">
          <h3>Made with Freebuff</h3>
          <p>
            Freebuff is the desktop/cloud agent that wrote this project. Open a chat, describe what
            you want, and it edits real files, runs the build and ships the site.
          </p>
          <a href="https://freebuff.com" target="_blank" rel="noreferrer" className="panel-link">
            freebuff.com →
          </a>
        </article>

        <article className="panel">
          <h3>Games</h3>
          <p>
            Chess-style board and card classics are hand-written for this site — no third-party
            embeds, so nothing here depends on an outside host staying online.
          </p>
          <a href="https://wasm.rip" target="_blank" rel="noreferrer" className="panel-link">
            More games at wasm.rip →
          </a>
        </article>

        <article className="panel">
          <h3>Stack</h3>
          <ul className="stack-list">
            <li>React + TypeScript</li>
            <li>Vite build</li>
            <li>Cloudflare Worker for the AI route</li>
            <li>No tracking, no analytics</li>
          </ul>
        </article>

        <article className="panel">
          <h3>Notes</h3>
          <p>
            Settings, pinned pages and your display name live in this browser's local storage. The
            passcode is checked on the client, so treat it as a curtain, not real security.
          </p>
        </article>
      </div>

      <p className="credit-foot">
        Thanks for playing. If this helped, pass the source zip to a friend — it is the whole thing.
      </p>
    </div>
  );
}
