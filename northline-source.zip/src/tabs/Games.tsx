import { useState } from 'react';
import TicTacToe from '../games/TicTacToe';
import ConnectFour from '../games/ConnectFour';
import Checkers from '../games/Checkers';
import Reversi from '../games/Reversi';
import TwentyFortyEight from '../games/TwentyFortyEight';
import GoFish from '../games/GoFish';

type GameId = 'ttt' | 'c4' | 'checkers' | 'reversi' | '2048' | 'gofish';

const GAMES: {
  id: GameId;
  title: string;
  blurb: string;
  players: string;
  icon: string;
  tint: string;
}[] = [
  {
    id: 'ttt',
    title: 'Tic-Tac-Toe',
    blurb: 'Three in a row against a perfect minimax opponent.',
    players: '1 player',
    icon: '✕',
    tint: 'violet',
  },
  {
    id: 'c4',
    title: 'Connect Four',
    blurb: 'Drop discs, build a line of four before the computer does.',
    players: '1 player',
    icon: '◍',
    tint: 'amber',
  },
  {
    id: 'checkers',
    title: 'Checkers',
    blurb: 'Full 8×8 draughts with mandatory captures and kings.',
    players: '1 player',
    icon: '◉',
    tint: 'rose',
  },
  {
    id: 'reversi',
    title: 'Reversi',
    blurb: 'Othello rules — flip discs, take the corners, control the board.',
    players: '1 player',
    icon: '◐',
    tint: 'teal',
  },
  {
    id: '2048',
    title: '2048',
    blurb: 'Slide and merge tiles until you hit 2048.',
    players: 'Solo',
    icon: '⧉',
    tint: 'blue',
  },
  {
    id: 'gofish',
    title: 'Go Fish',
    blurb: 'Classic card game — ask friends for ranks, collect books.',
    players: '1–3 friends',
    icon: '♠',
    tint: 'green',
  },
];

export default function Games() {
  const [active, setActive] = useState<GameId | null>(null);

  if (active) {
    const meta = GAMES.find((g) => g.id === active)!;
    return (
      <div className="games">
        <button type="button" className="game-back" onClick={() => setActive(null)}>
          ← All games
        </button>
        <div className="game-stage">
          {active === 'ttt' && <TicTacToe />}
          {active === 'c4' && <ConnectFour />}
          {active === 'checkers' && <Checkers />}
          {active === 'reversi' && <Reversi />}
          {active === '2048' && <TwentyFortyEight />}
          {active === 'gofish' && <GoFish />}
        </div>
        <p className="game-caption">{meta.blurb}</p>
      </div>
    );
  }

  return (
    <div className="games">
      <div className="games-grid">
        {GAMES.map((game) => (
          <button
            key={game.id}
            type="button"
            className={`game-card tint-${game.tint}`}
            onClick={() => setActive(game.id)}
          >
            <span className="game-icon" aria-hidden="true">
              {game.icon}
            </span>
            <span className="game-meta">
              <strong>{game.title}</strong>
              <small>{game.blurb}</small>
            </span>
            <span className="game-tag">{game.players}</span>
          </button>
        ))}

        <a
          className="game-card tint-outline"
          href="https://wasm.rip"
          target="_blank"
          rel="noreferrer"
        >
          <span className="game-icon" aria-hidden="true">
            ↗
          </span>
          <span className="game-meta">
            <strong>More games</strong>
            <small>The wasm.rip catalogue, opened in a new tab.</small>
          </span>
          <span className="game-tag">External</span>
        </a>
      </div>
    </div>
  );
}
