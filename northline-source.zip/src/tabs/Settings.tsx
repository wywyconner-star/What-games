import { FAVICONS, DEFAULT_SETTINGS, useSettings, type Settings } from '../lib/store';

const PRESETS: { label: string; title: string; favicon: string }[] = [
  {
    label: 'IXL worksheet',
    title: 'IXL | Math, Language Arts, Science, Social Studies, and Spanish',
    favicon: 'ixl',
  },
  { label: 'Google Classroom', title: 'Classes | Google Classroom', favicon: 'classroom' },
  { label: 'Algebra doc', title: 'Unit 4 Practice — Algebra 1 - Google Docs', favicon: 'docs' },
  { label: 'Drive folder', title: 'My Drive - Google Drive', favicon: 'drive' },
];

const PANIC_KEYS = ['Escape', 'Tab', '`', ']', '~'];

export default function Settings({ onPanic }: { onPanic: () => void }) {
  const { settings, set, reset } = useSettings();

  return (
    <div className="settings">
      <section className="panel">
        <header className="panel-head">
          <h2>Tab cloak</h2>
          <p>What the browser tab says while this page is open.</p>
        </header>

        <label className="field">
          <span>Tab title</span>
          <input
            value={settings.tabTitle}
            onChange={(e) => set('tabTitle', e.target.value)}
            placeholder={DEFAULT_SETTINGS.tabTitle}
            spellCheck={false}
          />
        </label>

        <div className="presets">
          {PRESETS.map((preset) => (
            <button
              key={preset.label}
              type="button"
              className="chip"
              onClick={() => {
                set('tabTitle', preset.title);
                set('favicon', preset.favicon);
              }}
            >
              {preset.label}
            </button>
          ))}
        </div>

        <div className="field">
          <span>Favicon</span>
          <div className="favicon-grid">
            {FAVICONS.map((fav) => (
              <button
                key={fav.id}
                type="button"
                className={`favicon-choice${settings.favicon === fav.id ? ' active' : ''}`}
                onClick={() => set('favicon', fav.id)}
                aria-pressed={settings.favicon === fav.id}
              >
                <img src={fav.href} alt="" width={22} height={22} />
                <span>{fav.label}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="panel">
        <header className="panel-head">
          <h2>Panic</h2>
          <p>Press this key to jump straight back to the course portal.</p>
        </header>

        <label className="field">
          <span>Panic key</span>
          <select
            value={settings.panicKey}
            onChange={(e) => set('panicKey', e.target.value)}
          >
            {PANIC_KEYS.map((key) => (
              <option key={key} value={key}>
                {key === ' ' ? 'Space' : key} {key === 'Escape' ? '(default)' : ''}
              </option>
            ))}
          </select>
        </label>

        <div className="row">
          <button type="button" className="btn btn-danger" onClick={onPanic}>
            Test panic now
          </button>
          <p className="row-note">
            Never opens a new page, so there is no history entry to explain.
          </p>
        </div>
      </section>

      <section className="panel">
        <header className="panel-head">
          <h2>Account</h2>
          <p>Your name shows on the credits page and in the portal footer.</p>
        </header>
        <label className="field">
          <span>Display name</span>
          <input
            value={settings.ownerName}
            onChange={(e) => set('ownerName', e.target.value.slice(0, 40))}
            placeholder="Your name"
          />
        </label>
      </section>

      <section className="panel">
        <header className="panel-head">
          <h2>Appearance</h2>
          <p>Cosmetic only — the portal is unaffected.</p>
        </header>
        <div className="field">
          <span>Theme</span>
          <div className="presets">
            {(['dusk', 'dark', 'light'] as Settings['theme'][]).map((theme) => (
              <button
                key={theme}
                type="button"
                className={`chip${settings.theme === theme ? ' chip-on' : ''}`}
                onClick={() => set('theme', theme)}
              >
                {theme}
              </button>
            ))}
          </div>
        </div>
        <label className="switch">
          <input
            type="checkbox"
            checked={settings.reduceMotion}
            onChange={(e) => set('reduceMotion', e.target.checked)}
          />
          <span>Reduce motion</span>
        </label>
      </section>

      <section className="panel panel-quiet">
        <header className="panel-head">
          <h2>Reset</h2>
          <p>Restore the default tab title, favicon, panic key and theme.</p>
        </header>
        <button type="button" className="btn btn-ghost" onClick={reset}>
          Restore defaults
        </button>
      </section>
    </div>
  );
}
