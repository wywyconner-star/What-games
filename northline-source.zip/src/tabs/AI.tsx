import { useEffect, useRef, useState } from 'react';

type Msg = { role: 'user' | 'assistant'; content: string };

const SYSTEM =
  'You are Northline Study Assistant, a friendly tutor for a middle/high school student. ' +
  'Explain clearly and briefly, use short paragraphs or steps, and show worked reasoning for math. ' +
  'If a request is unclear, ask one short clarifying question. Never claim to be a human.';

const STARTERS = [
  'Explain solving systems of equations by substitution.',
  'Give me 5 practice questions on cell organelles.',
  'Help me outline a 5-paragraph essay on the Industrial Revolution.',
  'Make a 20-minute study plan for a biology quiz tomorrow.',
];

export default function AI() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<{ code: string; message: string } | null>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, busy]);

  const send = async (text: string) => {
    const prompt = text.trim();
    if (!prompt || busy) return;
    const next = [...messages, { role: 'user' as const, content: prompt }];
    setMessages(next);
    setInput('');
    setBusy(true);
    setError(null);

    try {
      const res = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ messages: [{ role: 'system', content: SYSTEM }, ...next] }),
      });
      const data = await res.json().catch(() => null);

      if (!res.ok || !data) {
        setError({
          code: data?.error ?? 'request_failed',
          message:
            data?.message ??
            'The assistant could not be reached. Check your connection and try again.',
        });
        return;
      }

      const reply: string | undefined =
        data?.choices?.[0]?.message?.content ?? data?.reply ?? data?.content;
      if (!reply) {
        setError({ code: 'bad_response', message: 'The assistant returned an empty reply.' });
        return;
      }
      setMessages((prev) => [...prev, { role: 'assistant', content: reply }]);
    } catch (err) {
      setError({ code: 'network_error', message: String(err) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="ai">
      {error?.code === 'missing_key' && (
        <div className="callout">
          <strong>AI key not set yet</strong>
          <p>
            The assistant endpoint is wired up, but this deployment has no{' '}
            <code>OPENAI_API_KEY</code>. Add it in the project secrets (or <code>.env</code> for
            local dev), redeploy, and this panel starts working. Nothing else needs to change.
          </p>
          <p className="callout-small">{error.message}</p>
        </div>
      )}

      {error && error.code !== 'missing_key' && (
        <div className="callout callout-bad">
          <strong>Something went wrong</strong>
          <p>{error.message}</p>
          <p className="callout-small">Error code: {error.code}</p>
        </div>
      )}

      <div className="chat" ref={listRef}>
        {messages.length === 0 && (
          <div className="chat-empty">
            <div className="chat-orb">✦</div>
            <h2>Ask anything you're stuck on</h2>
            <p>Homework help, explanations, practice questions, study plans.</p>
            <div className="starters">
              {STARTERS.map((s) => (
                <button key={s} type="button" className="starter" onClick={() => send(s)}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`bubble ${msg.role}`}>
            <span className="bubble-who">{msg.role === 'user' ? 'You' : 'Assistant'}</span>
            <div className="bubble-text">{msg.content}</div>
          </div>
        ))}

        {busy && (
          <div className="bubble assistant">
            <span className="bubble-who">Assistant</span>
            <div className="bubble-text typing">
              <i />
              <i />
              <i />
            </div>
          </div>
        )}
      </div>

      <form
        className="composer"
        onSubmit={(e) => {
          e.preventDefault();
          void send(input);
        }}
      >
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              void send(input);
            }
          }}
          rows={2}
          placeholder="Ask a question… (Enter to send, Shift+Enter for a new line)"
        />
        <div className="composer-foot">
          <button
            type="button"
            className="chip"
            onClick={() => {
              setMessages([]);
              setError(null);
            }}
            disabled={!messages.length || busy}
          >
            New chat
          </button>
          <button type="submit" className="btn btn-primary" disabled={busy || !input.trim()}>
            {busy ? 'Thinking…' : 'Send'}
          </button>
        </div>
      </form>
    </div>
  );
}
