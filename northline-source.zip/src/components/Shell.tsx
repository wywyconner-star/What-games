import { useState } from 'react';
import Home from '../tabs/Home';
import Games from '../tabs/Games';
import AI from '../tabs/AI';
import Settings from '../tabs/Settings';
import Credits from '../tabs/Credits';

type TabId = 'home' | 'games' | 'ai' | 'settings' | 'credits';

const TABS: { id: TabId; label: string; icon: JSX.Element }[] = [
  {
    id: 'home',
    label: 'Home',
    icon: (
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M4 11.5 12 4l8 7.5" />
        <path d="M6.5 10.5V20h11v-9.5" />
      </svg>
    ),
  },
  {
    id: 'games',
    label: 'Games',
    icon: (
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <rect x="3" y="7" width="18" height="11" rx="4" />
        <path d="M8 12.5h3M9.5 11v3M15.5 12h.01M17.5 14h.01" />
      </svg>
    ),
  },
  {
    id: 'ai',
    label: 'AI',
    icon: (
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 3l1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9z" />
        <path d="M18 16.5l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9z" />
      </svg>
    ),
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: (
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.2-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4.6 2 2 0 1 1 14 4.6a1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4z" />
      </svg>
    ),
  },
  {
    id: 'credits',
    label: 'Credits',
    icon: (
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <circle cx="12" cy="9" r="3.4" />
        <path d="M5 20c.8-3.4 3.6-5.2 7-5.2s6.2 1.8 7 5.2" />
      </svg>
    ),
  },
];

const TITLES: Record<TabId, { title: string; sub: string }> = {
  home: { title: 'Open anything', sub: 'Paste a link and it runs inside this tab.' },
  games: { title: 'Board games', sub: 'Classic strategy and card games, built right in.' },
  ai: { title: 'Study assistant', sub: 'Ask questions, get explanations, plan your week.' },
  settings: { title: 'Settings', sub: 'Cloak the tab, choose a panic key, tune the look.' },
  credits: { title: 'Credits', sub: 'Who built this and how to take the source with you.' },
};

export default function Shell({ onPanic }: { onPanic: () => void }) {
  const [tab, setTab] = useState<TabId>('home');

  return (
    <div className="shell">
      <aside className="side">
        <div className="side-brand">
          <span className="brand-mark" aria-hidden="true">
            N
          </span>
          <span>
            <strong>Northline</strong>
            <em>student hub</em>
          </span>
        </div>

        <nav className="side-nav" aria-label="Sections">
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              className={`side-item${tab === item.id ? ' active' : ''}`}
              onClick={() => setTab(item.id)}
              aria-current={tab === item.id ? 'page' : undefined}
            >
              <span className="side-icon">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="side-foot">
          <button type="button" className="panic" onClick={onPanic}>
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 4l8 15H4z" />
              <path d="M12 10v4M12 16.6h.01" />
            </svg>
            Panic <kbd>esc</kbd>
          </button>
          <small>v1.0 · local build</small>
        </div>
      </aside>

      <main className="main">
        <header className="main-head">
          <div>
            <h1>{TITLES[tab].title}</h1>
            <p>{TITLES[tab].sub}</p>
          </div>
          <button type="button" className="btn btn-ghost focus-btn" onClick={onPanic}>
            Focus mode
          </button>
        </header>

        <div className="main-body">
          {tab === 'home' && <Home />}
          {tab === 'games' && <Games />}
          {tab === 'ai' && <AI />}
          {tab === 'settings' && <Settings onPanic={onPanic} />}
          {tab === 'credits' && <Credits />}
        </div>
      </main>
    </div>
  );
}
