import { useMemo, useState } from 'react';
import { useSettings } from '../lib/store';

const SUBJECTS = [
  { name: 'Math', letter: 'M', count: '4,312 skills', tone: 'violet' },
  { name: 'Language Arts', letter: 'L', count: '3,187 skills', tone: 'teal' },
  { name: 'Science', letter: 'S', count: '1,906 skills', tone: 'blue' },
  { name: 'Social Studies', letter: 'H', count: '1,244 skills', tone: 'amber' },
  { name: 'Spanish', letter: 'E', count: '870 skills', tone: 'rose' },
  { name: 'Test Prep', letter: 'T', count: '512 skills', tone: 'green' },
];

const CONTINUE = [
  { title: 'Solve multi-step equations', subject: 'Algebra 1', progress: 72 },
  { title: 'Cite evidence from a text', subject: 'Grade 9 ELA', progress: 45 },
  { title: 'Cell structures and function', subject: 'Biology', progress: 88 },
];

const STATS = [
  { value: '12.4M', label: 'students practicing' },
  { value: '8,600+', label: 'learning skills' },
  { value: '95', label: 'countries' },
  { value: '4.8/5', label: 'teacher rating' },
];

export default function Portal({ onOpenGate }: { onOpenGate: () => void }) {
  const { settings } = useSettings();
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');

  const year = useMemo(() => new Date().getFullYear(), []);

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const trimmed = query.trim();
    if (trimmed === '1234') {
      onOpenGate();
      setQuery('');
      return;
    }
    setNotice(
      trimmed
        ? `No skill matched “${trimmed}”. Try a topic like “fractions” or browse a subject below.`
        : 'Type a skill, topic or standard to search the curriculum.',
    );
    window.setTimeout(() => setNotice(''), 4200);
  };

  return (
    <div className="portal">
      <header className="portal-top">
        <div className="portal-top-inner">
          <a className="brand" href="/">
            <span className="brand-mark" aria-hidden="true">
              N
            </span>
            <span className="brand-text">
              <strong>Northline</strong>
              <em>Learning</em>
            </span>
          </a>
          <nav className="portal-nav">
            <span>Learning</span>
            <span>Analytics</span>
            <span>Diagnostic</span>
            <span>Resources</span>
            <span>Pricing</span>
          </nav>
          <div className="portal-top-actions">
            <button className="btn btn-quiet" type="button" onClick={onOpenGate}>
              Sign in
            </button>
            <button className="btn btn-solid" type="button" onClick={onOpenGate}>
              Start free trial
            </button>
          </div>
        </div>
      </header>

      <section className="hero">
        <div className="hero-inner">
          <p className="hero-eyebrow">K-12 personalized practice</p>
          <h1>
            Practice that feels like
            <br />
            <span>progress.</span>
          </h1>
          <p className="hero-lede">
            Unlimited questions across 8,600+ skills, instant feedback, and a diagnostic that shows
            exactly what to work on next.
          </p>

          <form className="hero-search" onSubmit={submitSearch} role="search">
            <svg viewBox="0 0 24 24" aria-hidden="true" className="search-icon">
              <circle cx="11" cy="11" r="7" />
              <path d="M16.5 16.5 21 21" />
            </svg>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search 8,600+ skills, e.g. “linear equations”"
              aria-label="Search skills"
            />
            <button type="submit" className="btn btn-solid">
              Search
            </button>
          </form>
          {notice && <p className="hero-notice">{notice}</p>}

          <div className="hero-meta">
            <span>✓ Aligned to state standards</span>
            <span>✓ Free for classrooms</span>
            <span>✓ Works on any device</span>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="art-card art-card-a">
            <span className="art-chip">Algebra 1</span>
            <strong>Solving systems</strong>
            <div className="art-bar">
              <i style={{ width: '68%' }} />
            </div>
            <small>68% mastery</small>
          </div>
          <div className="art-card art-card-b">
            <span className="art-chip">Weekly report</span>
            <div className="art-spark">
              {[38, 52, 44, 66, 58, 78, 88].map((h, i) => (
                <i key={i} style={{ height: `${h}%` }} />
              ))}
            </div>
            <small>+12% this week</small>
          </div>
          <div className="art-ring" />
        </div>
      </section>

      <section className="subjects">
        <div className="section-inner">
          <div className="section-head">
            <h2>Browse by subject</h2>
            <p>Every skill includes unlimited questions, hints and step-by-step explanations.</p>
          </div>
          <div className="subject-grid">
            {SUBJECTS.map((subject) => (
              <button
                key={subject.name}
                type="button"
                className={`subject-card tone-${subject.tone}`}
                onClick={() => setNotice(`Showing the ${subject.name} curriculum preview.`)}
              >
                <span className="subject-letter">{subject.letter}</span>
                <span className="subject-body">
                  <strong>{subject.name}</strong>
                  <small>{subject.count}</small>
                </span>
                <svg viewBox="0 0 24 24" aria-hidden="true" className="subject-arrow">
                  <path d="M9 6l6 6-6 6" />
                </svg>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="continue">
        <div className="section-inner">
          <div className="section-head">
            <h2>Continue where you left off</h2>
            <p>Recommendations refresh every Sunday based on your diagnostic results.</p>
          </div>
          <div className="continue-grid">
            {CONTINUE.map((item) => (
              <article key={item.title} className="continue-card">
                <span className="continue-subject">{item.subject}</span>
                <h3>{item.title}</h3>
                <div className="continue-bar">
                  <i style={{ width: `${item.progress}%` }} />
                </div>
                <div className="continue-foot">
                  <small>{item.progress}% complete</small>
                  <span>Resume →</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="stats">
        <div className="section-inner stats-inner">
          {STATS.map((stat) => (
            <div key={stat.label} className="stat">
              <strong>{stat.value}</strong>
              <span>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <footer className="portal-foot">
        <div className="section-inner foot-inner">
          <div>
            <div className="brand brand-foot">
              <span className="brand-mark" aria-hidden="true">
                N
              </span>
              <span className="brand-text">
                <strong>Northline</strong>
                <em>Learning</em>
              </span>
            </div>
            <p className="foot-note">
              © {year} Northline Learning, Inc. Standards-aligned practice for every learner.
            </p>
          </div>
          <div className="foot-links">
            <button type="button" onClick={onOpenGate}>
              Educator sign in
            </button>
            <span>Privacy</span>
            <span>Terms</span>
            <span>Accessibility</span>
            <span>Support</span>
          </div>
          <p className="foot-owner">Family account: {settings.ownerName}</p>
        </div>
      </footer>
    </div>
  );
}
