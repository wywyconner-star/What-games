import { useEffect, useRef, useState } from 'react';

type Props = {
  open: boolean;
  onClose: () => void;
  onUnlock: () => void;
};

const PASSCODE = '5656';

export default function Gate({ open, onClose, onUnlock }: Props) {
  const [value, setValue] = useState('');
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setValue('');
      setError('');
      const timer = window.setTimeout(() => inputRef.current?.focus(), 60);
      return () => window.clearTimeout(timer);
    }
  }, [open]);

  if (!open) return null;

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (value.trim() === PASSCODE) {
      onUnlock();
      return;
    }
    setError('That key is not valid for this account.');
    setShake(true);
    window.setTimeout(() => setShake(false), 450);
    setValue('');
    inputRef.current?.focus();
  };

  return (
    <div className="gate-scrim" role="dialog" aria-modal="true" aria-label="Staff sign in" onMouseDown={onClose}>
      <form
        className={`gate-card${shake ? ' shake' : ''}`}
        onSubmit={submit}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="gate-badge">NL</div>
        <h2>Staff &amp; family access</h2>
        <p className="gate-sub">
          Enter the 4-digit access key provided by your school administrator to open the family
          dashboard.
        </p>
        <label className="gate-label" htmlFor="gate-input">
          Access key
        </label>
        <input
          id="gate-input"
          ref={inputRef}
          className="gate-input"
          inputMode="numeric"
          autoComplete="off"
          maxLength={4}
          placeholder="••••"
          value={value}
          onChange={(e) => setValue(e.target.value.replace(/\D/g, '').slice(0, 4))}
        />
        {error && <p className="gate-error">{error}</p>}
        <div className="gate-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={value.length < 4}>
            Continue
          </button>
        </div>
        <p className="gate-foot">Northline Learning · Secure staff portal</p>
      </form>
    </div>
  );
}
