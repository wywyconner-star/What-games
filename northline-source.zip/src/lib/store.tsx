import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

export type Settings = {
  tabTitle: string;
  favicon: string;
  panicKey: string;
  ownerName: string;
  theme: 'dusk' | 'dark' | 'light';
  reduceMotion: boolean;
};

export const FAVICONS: { id: string; label: string; href: string }[] = [
  {
    id: 'ixl',
    label: 'IXL',
    href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%233d2f8f'/%3E%3Cpath d='M20 46V18l24 28V18' stroke='white' stroke-width='6' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E",
  },
  {
    id: 'classroom',
    label: 'Classroom',
    href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%230f9d58'/%3E%3Crect x='14' y='14' width='36' height='36' rx='4' fill='none' stroke='white' stroke-width='5'/%3E%3Cpath d='M32 22v20M22 32h20' stroke='white' stroke-width='5'/%3E%3C/svg%3E",
  },
  {
    id: 'docs',
    label: 'Docs',
    href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='8' fill='%232a6df5'/%3E%3Cpath d='M20 14h16l10 10v26H20z' fill='white'/%3E%3Cpath d='M24 32h16M24 40h16' stroke='%232a6df5' stroke-width='3'/%3E%3C/svg%3E",
  },
  {
    id: 'drive',
    label: 'Drive',
    href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='10' fill='%23f5f5f5'/%3E%3Cpath d='M25 12h14l14 24H39z' fill='%23fbbc04'/%3E%3Cpath d='M25 12L11 36l7 12 14-24z' fill='%230f9d58'/%3E%3Cpath d='M18 48h28l7-12H25z' fill='%234285f4'/%3E%3C/svg%3E",
  },
  {
    id: 'desmos',
    label: 'Graphing',
    href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='10' fill='%231c7d3b'/%3E%3Cpath d='M12 44c8 0 8-24 20-24s12 24 20 24' stroke='white' stroke-width='5' fill='none'/%3E%3C/svg%3E",
  },
  {
    id: 'wikipedia',
    label: 'Wikipedia',
    href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='10' fill='%23f8f9fa' stroke='%23c8ccd1'/%3E%3Ctext x='32' y='44' font-family='serif' font-size='32' text-anchor='middle' fill='%23202122'%3EW%3C/text%3E%3C/svg%3E",
  },
];

export const DEFAULT_SETTINGS: Settings = {
  tabTitle: 'IXL | Math, Language Arts, Science, Social Studies, and Spanish',
  favicon: 'ixl',
  panicKey: 'Escape',
  ownerName: 'Your name',
  theme: 'dusk',
  reduceMotion: false,
};

const KEY = 'northline.settings.v1';

function load(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<Settings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

type Ctx = {
  settings: Settings;
  set: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  reset: () => void;
  faviconHref: string;
};

const SettingsContext = createContext<Ctx | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(() =>
    typeof window === 'undefined' ? DEFAULT_SETTINGS : load(),
  );

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(settings));
    } catch {
      /* storage can be unavailable in private mode */
    }
  }, [settings]);

  // Tab cloaking: keep the document title + favicon looking like schoolwork.
  useEffect(() => {
    document.title = settings.tabTitle || DEFAULT_SETTINGS.tabTitle;
    const href =
      FAVICONS.find((f) => f.id === settings.favicon)?.href ?? FAVICONS[0].href;
    let link = document.querySelector<HTMLLinkElement>("link[rel~='icon']");
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    link.href = href;
  }, [settings.tabTitle, settings.favicon]);

  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
    document.documentElement.dataset.reduceMotion = String(settings.reduceMotion);
  }, [settings.theme, settings.reduceMotion]);

  const set = useCallback(<K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  }, []);

  const reset = useCallback(() => setSettings(DEFAULT_SETTINGS), []);

  const faviconHref = useMemo(
    () => FAVICONS.find((f) => f.id === settings.favicon)?.href ?? FAVICONS[0].href,
    [settings.favicon],
  );

  return (
    <SettingsContext.Provider value={{ settings, set, reset, faviconHref }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings(): Ctx {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used inside SettingsProvider');
  return ctx;
}
