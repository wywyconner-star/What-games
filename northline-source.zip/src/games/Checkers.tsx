import { useEffect, useMemo, useRef, useState } from 'react';

type Player = 1 | 2;
type Piece = { p: Player; king: boolean };
type Board = (Piece | null)[][];
type Pos = [number, number];
type Move = { from: Pos; to: Pos; cap: Pos | null };
type Game = { board: Board; turn: Player; chain: Pos | null; winner: Player | 0 | null };

const DIRS: [number, number][] = [
  [-1, -1],
  [-1, 1],
  [1, -1],
  [1, 1],
];

const inBounds = (r: number, c: number) => r >= 0 && r < 8 && c >= 0 && c < 8;

function startBoard(): Board {
  const board: Board = Array.from({ length: 8 }, () => Array<Piece | null>(8).fill(null));
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if ((r + c) % 2 === 0) continue;
      if (r < 3) board[r][c] = { p: 2, king: false };
      else if (r > 4) board[r][c] = { p: 1, king: false };
    }
  }
  return board;
}

function jumpsFrom(board: Board, r: number, c: number): Move[] {
  const piece = board[r][c];
  if (!piece) return [];
  const out: Move[] = [];
  for (const [dr, dc] of DIRS) {
    const mr = r + dr;
    const mc = c + dc;
    const jr = r + dr * 2;
    const jc = c + dc * 2;
    if (!inBounds(jr, jc)) continue;
    const middle = board[mr][mc];
    if (middle && middle.p !== piece.p && !board[jr][jc]) {
      out.push({ from: [r, c], to: [jr, jc], cap: [mr, mc] });
    }
  }
  return out;
}

function movesFor(board: Board, r: number, c: number): Move[] {
  const piece = board[r][c];
  if (!piece) return [];
  const out: Move[] = [];
  for (const [dr, dc] of DIRS) {
    const nr = r + dr;
    const nc = c + dc;
    if (!inBounds(nr, nc) || board[nr][nc]) continue;
    const forward = piece.p === 1 ? dr === -1 : dr === 1;
    if (!piece.king && !forward) continue;
    out.push({ from: [r, c], to: [nr, nc], cap: null });
  }
  return [...out, ...jumpsFrom(board, r, c)];
}

function legalMoves(board: Board, player: Player, chain: Pos | null): Move[] {
  if (chain) return jumpsFrom(board, chain[0], chain[1]);
  const all: Move[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (board[r][c]?.p === player) all.push(...movesFor(board, r, c));
    }
  }
  const captures = all.filter((m) => m.cap);
  return captures.length ? captures : all;
}

function applyMove(board: Board, move: Move): { board: Board; promoted: boolean; mover: Player } {
  const next = board.map((row) => row.slice()) as Board;
  const piece = next[move.from[0]][move.from[1]]!;
  const mover = piece.p;
  next[move.from[0]][move.from[1]] = null;
  if (move.cap) next[move.cap[0]][move.cap[1]] = null;

  let upgraded = piece;
  let promoted = false;
  if (!piece.king && ((piece.p === 1 && move.to[0] === 0) || (piece.p === 2 && move.to[0] === 7))) {
    upgraded = { ...piece, king: true };
    promoted = true;
  }
  next[move.to[0]][move.to[1]] = upgraded;
  return { board: next, promoted, mover };
}

function playMove(game: Game, move: Move): Game {
  const { board, promoted, mover } = applyMove(game.board, move);
  const opponent: Player = mover === 1 ? 2 : 1;
  const chained = move.cap && !promoted ? jumpsFrom(board, move.to[0], move.to[1]) : [];
  const turn = chained.length ? mover : opponent;
  const nextGame: Game = {
    board,
    turn,
    chain: chained.length ? move.to : null,
    winner: null,
  };
  const options = legalMoves(board, turn, nextGame.chain);
  if (options.length === 0) nextGame.winner = opponent;
  return nextGame;
}

function countPieces(board: Board, player: Player): number {
  let n = 0;
  for (const row of board) for (const cell of row) if (cell?.p === player) n++;
  return n;
}

function pickAi(game: Game): Move | null {
  const moves = legalMoves(game.board, 2, game.chain);
  if (!moves.length) return null;
  const scored = moves.map((move) => {
    let score = Math.random() * 2;
    if (move.cap) score += 60;
    if (move.cap) {
      const after = applyMove(game.board, move);
      const reply = legalMoves(after.board, 1, null);
      score -= reply.filter((m) => m.cap).length * 4;
    }
    score += move.to[0] * 1.6; // advance toward promotion
    score += 3.5 - Math.abs(3.5 - move.to[1]);
    if (move.to[0] === 7) score += 25;
    return { move, score };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored[0].move;
}

const sig = (game: Game) =>
  `${game.turn}|${game.board.map((r) => r.map((p) => (p ? `${p.p}${p.king ? 'k' : ''}` : '-')).join('')).join('')}`;

export default function Checkers() {
  const [game, setGame] = useState<Game>(() => ({
    board: startBoard(),
    turn: 1,
    chain: null,
    winner: null,
  }));
  const [selected, setSelected] = useState<Pos | null>(null);
  const lastAi = useRef('');

  const options = useMemo(
    () => legalMoves(game.board, game.turn, game.chain),
    [game.board, game.turn, game.chain],
  );

  const movable = useMemo(() => {
    const set = new Set<string>();
    for (const m of options) set.add(`${m.from[0]}-${m.from[1]}`);
    return set;
  }, [options]);

  // After a jump the same piece must keep jumping, so keep it active.
  const activeSelection = selected ?? game.chain;

  const targets = useMemo(() => {
    const set = new Set<string>();
    if (!activeSelection) return set;
    for (const m of options) {
      if (m.from[0] === activeSelection[0] && m.from[1] === activeSelection[1]) {
        set.add(`${m.to[0]}-${m.to[1]}`);
      }
    }
    return set;
  }, [options, activeSelection]);

  useEffect(() => {
    if (game.winner || game.turn !== 2) return;
    const signature = sig(game);
    if (lastAi.current === signature) return;
    lastAi.current = signature;
    const timer = window.setTimeout(() => {
      const move = pickAi(game);
      if (move) setGame((g) => playMove(g, move));
    }, 460);
    return () => window.clearTimeout(timer);
  }, [game]);

  const onSquare = (r: number, c: number) => {
    if (game.winner || game.turn !== 1) return;
    const key = `${r}-${c}`;
    if (activeSelection && targets.has(key)) {
      const move = options.find(
        (m) =>
          m.from[0] === activeSelection[0] &&
          m.from[1] === activeSelection[1] &&
          m.to[0] === r &&
          m.to[1] === c,
      );
      if (move) {
        setGame((g) => playMove(g, move));
        setSelected(null);
      }
      return;
    }
    if (movable.has(key)) setSelected([r, c]);
    else setSelected(null);
  };

  const status = game.winner
    ? game.winner === 1
      ? 'You win!'
      : 'Computer wins.'
    : game.turn === 2
      ? 'Computer is moving…'
      : game.chain
        ? 'Keep jumping!'
        : 'Your move — you are red.';

  return (
    <div className="game">
      <div className="game-top">
        <div>
          <h3>Checkers</h3>
          <p className="game-sub">
            8×8 draughts. Captures are mandatory; men promote to kings on the far row.
          </p>
        </div>
        <div className="scoreline">
          <span>Red {countPieces(game.board, 1)}</span>
          <span>Blue {countPieces(game.board, 2)}</span>
        </div>
      </div>

      <div className="checkers-board">
        {game.board.map((row, r) =>
          row.map((piece, c) => {
            const dark = (r + c) % 2 === 1;
            const key = `${r}-${c}`;
            return (
              <button
                key={key}
                type="button"
                className={[
                  'checkers-sq',
                  dark ? 'dark' : 'light',
                  selected?.[0] === r && selected?.[1] === c ? 'selected' : '',
                  targets.has(key) ? 'target' : '',
                  movable.has(key) ? 'movable' : '',
                ]
                  .filter(Boolean)
                  .join(' ')}
                onClick={() => onSquare(r, c)}
                disabled={!dark}
                aria-label={`Row ${r + 1} column ${c + 1}`}
              >
                {piece && (
                  <span className={`checker p${piece.p}${piece.king ? ' king' : ''}`}>
                    {piece.king ? '♔' : ''}
                  </span>
                )}
              </button>
            );
          }),
        )}
      </div>

      <div className="game-foot">
        <span className={`game-status${game.winner === 1 ? ' good' : ''}`}>{status}</span>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => {
            setGame({ board: startBoard(), turn: 1, chain: null, winner: null });
            setSelected(null);
            lastAi.current = '';
          }}
        >
          {game.winner ? 'Play again' : 'Reset'}
        </button>
      </div>
    </div>
  );
}
