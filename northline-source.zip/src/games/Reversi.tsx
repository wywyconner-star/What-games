import { useEffect, useMemo, useState } from 'react';

type Board = number[][]; // 0 empty, 1 you, 2 computer
type Pos = [number, number];

const DIRS: [number, number][] = [
  [-1, -1],
  [-1, 0],
  [-1, 1],
  [0, -1],
  [0, 1],
  [1, -1],
  [1, 0],
  [1, 1],
];

const CORNERS: Pos[] = [
  [0, 0],
  [0, 7],
  [7, 0],
  [7, 7],
];

const inB = (r: number, c: number) => r >= 0 && r < 8 && c >= 0 && c < 8;

function start(): Board {
  const board: Board = Array.from({ length: 8 }, () => Array<number>(8).fill(0));
  board[3][3] = 2;
  board[3][4] = 1;
  board[4][3] = 1;
  board[4][4] = 2;
  return board;
}

function flips(board: Board, r: number, c: number, player: number): Pos[] {
  if (board[r][c] !== 0) return [];
  const enemy = player === 1 ? 2 : 1;
  const all: Pos[] = [];
  for (const [dr, dc] of DIRS) {
    const line: Pos[] = [];
    let nr = r + dr;
    let nc = c + dc;
    while (inB(nr, nc) && board[nr][nc] === enemy) {
      line.push([nr, nc]);
      nr += dr;
      nc += dc;
    }
    if (line.length && inB(nr, nc) && board[nr][nc] === player) all.push(...line);
  }
  return all;
}

function legal(board: Board, player: number): { pos: Pos; flips: Pos[] }[] {
  const out: { pos: Pos; flips: Pos[] }[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const f = flips(board, r, c, player);
      if (f.length) out.push({ pos: [r, c], flips: f });
    }
  }
  return out;
}

function apply(board: Board, player: number, pos: Pos, list: Pos[]): Board {
  const next = board.map((row) => row.slice());
  next[pos[0]][pos[1]] = player;
  for (const [r, c] of list) next[r][c] = player;
  return next;
}

const count = (board: Board, player: number) =>
  board.flat().filter((v) => v === player).length;

export default function Reversi() {
  const [board, setBoard] = useState<Board>(start);
  const [turn, setTurn] = useState<1 | 2>(1);
  const [thinking, setThinking] = useState(false);
  const [score, setScore] = useState({ win: 0, loss: 0, draw: 0 });

  const moves = useMemo(() => legal(board, turn), [board, turn]);
  const aiMoves = useMemo(() => legal(board, 2), [board]);
  const over = moves.length === 0 && aiMoves.length === 0;

  useEffect(() => {
    if (over) return;
    if (turn === 2 && aiMoves.length) {
      setThinking(true);
      const timer = window.setTimeout(() => {
        const scored = aiMoves.map((move) => {
          let value = move.flips.length + Math.random();
          if (CORNERS.some(([r, c]) => r === move.pos[0] && c === move.pos[1])) value += 12;
          if (
            (move.pos[0] === 0 || move.pos[0] === 7) &&
            (move.pos[1] === 0 || move.pos[1] === 7)
          ) {
            value += 6;
          }
          return { move, value };
        });
        scored.sort((a, b) => b.value - a.value);
        const chosen = scored[0].move;
        setBoard(apply(board, 2, chosen.pos, chosen.flips));
        const playerMoves = legal(apply(board, 2, chosen.pos, chosen.flips), 1);
        setTurn(playerMoves.length ? 1 : 2);
        setThinking(false);
      }, 420);
      return () => window.clearTimeout(timer);
    }
    if (turn === 2 && !aiMoves.length) {
      setTurn(1);
    }
  }, [turn, aiMoves, board, over]);

  useEffect(() => {
    if (!over) return;
    const mine = count(board, 1);
    const theirs = count(board, 2);
    setScore((s) => ({
      win: s.win + (mine > theirs ? 1 : 0),
      loss: s.loss + (mine < theirs ? 1 : 0),
      draw: s.draw + (mine === theirs ? 1 : 0),
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [over]);

  // If the human has no legal move, pass automatically.
  useEffect(() => {
    if (over || turn !== 1 || moves.length) return;
    const timer = window.setTimeout(() => setTurn(2), 800);
    return () => window.clearTimeout(timer);
  }, [over, turn, moves.length]);

  const play = (r: number, c: number) => {
    if (over || turn !== 1 || thinking) return;
    const found = moves.find((m) => m.pos[0] === r && m.pos[1] === c);
    if (!found) return;
    const next = apply(board, 1, found.pos, found.flips);
    setBoard(next);
    const reply = legal(next, 2);
    setTurn(reply.length ? 2 : 1);
  };

  const hint = useMemo(() => new Set(moves.map((m) => `${m.pos[0]}-${m.pos[1]}`)), [moves]);

  const status = over
    ? count(board, 1) > count(board, 2)
      ? 'You win!'
      : count(board, 1) < count(board, 2)
        ? 'Computer wins.'
        : 'Draw.'
    : turn === 2
      ? 'Computer is thinking…'
      : moves.length
        ? 'Your turn — place on a highlighted square.'
        : 'No moves for you — passing.';

  return (
    <div className="game">
      <div className="game-top">
        <div>
          <h3>Reversi</h3>
          <p className="game-sub">
            Also called Othello. Surround enemy discs to flip them; most discs at the end wins.
          </p>
        </div>
        <div className="scoreline">
          <span>You {count(board, 1)}</span>
          <span>CPU {count(board, 2)}</span>
        </div>
      </div>

      <div className="reversi-board">
        {board.map((row, r) =>
          row.map((cell, c) => (
            <button
              key={`${r}-${c}`}
              type="button"
              className="reversi-sq"
              onClick={() => play(r, c)}
              disabled={turn !== 1 || !hint.has(`${r}-${c}`)}
              aria-label={`Row ${r + 1} column ${c + 1}`}
            >
              {cell !== 0 && <span className={`disc d${cell}`} />}
              {cell === 0 && hint.has(`${r}-${c}`) && <span className="disc-placeholder" />}
            </button>
          )),
        )}
      </div>

      <div className="game-foot">
        <span className="game-status">{status}</span>
        <span className="scoreline">
          <span>W {score.win}</span>
          <span>D {score.draw}</span>
          <span>L {score.loss}</span>
        </span>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => {
            setBoard(start());
            setTurn(1);
            setThinking(false);
          }}
        >
          {over ? 'Play again' : 'Reset'}
        </button>
      </div>
    </div>
  );
}
