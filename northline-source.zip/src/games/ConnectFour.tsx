import { useEffect, useMemo, useState } from 'react';

const ROWS = 6;
const COLS = 7;
type Cell = 0 | 1 | 2;
type Grid = Cell[][];

const empty = (): Grid => Array.from({ length: ROWS }, () => Array<Cell>(COLS).fill(0));

function landing(g: Grid, col: number): number {
  for (let r = ROWS - 1; r >= 0; r--) if (g[r][col] === 0) return r;
  return -1;
}

function place(g: Grid, col: number, p: Cell): Grid {
  const row = landing(g, col);
  if (row < 0) return g;
  const next = g.map((r) => r.slice()) as Grid;
  next[row][col] = p;
  return next;
}

function winLine(g: Grid): [number, number][] | null {
  const dirs = [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1],
  ];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const p = g[r][c];
      if (!p) continue;
      for (const [dr, dc] of dirs) {
        const cells: [number, number][] = [[r, c]];
        for (let k = 1; k < 4; k++) {
          const nr = r + dr * k;
          const nc = c + dc * k;
          if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS || g[nr][nc] !== p) break;
          cells.push([nr, nc]);
        }
        if (cells.length === 4) return cells;
      }
    }
  }
  return null;
}

const WEIGHT = [0, 1, 8, 60, 10000];

function evaluate(g: Grid): number {
  let score = 0;
  for (let r = 0; r < ROWS; r++) {
    if (g[r][3] === 2) score += 4;
    else if (g[r][3] === 1) score -= 4;
  }
  const dirs = [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1],
  ];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      for (const [dr, dc] of dirs) {
        const er = r + dr * 3;
        const ec = c + dc * 3;
        if (er < 0 || er >= ROWS || ec < 0 || ec >= COLS) continue;
        let ai = 0;
        let human = 0;
        for (let k = 0; k < 4; k++) {
          const v = g[r + dr * k][c + dc * k];
          if (v === 2) ai++;
          else if (v === 1) human++;
        }
        if (ai && human) continue;
        if (ai) score += WEIGHT[ai];
        if (human) score -= WEIGHT[human];
      }
    }
  }
  return score;
}

function search(g: Grid, depth: number, alpha: number, beta: number, max: boolean): number {
  const line = winLine(g);
  if (line) {
    const p = g[line[0][0]][line[0][1]];
    return p === 2 ? 100000 + depth : -100000 - depth;
  }
  if (depth === 0 || g[0].every((v) => v !== 0)) return evaluate(g);

  const order = [3, 2, 4, 1, 5, 0, 6];
  if (max) {
    let best = -Infinity;
    for (const c of order) {
      if (g[0][c] !== 0) continue;
      best = Math.max(best, search(place(g, c, 2), depth - 1, alpha, beta, false));
      alpha = Math.max(alpha, best);
      if (alpha >= beta) break;
    }
    return best;
  }
  let best = Infinity;
  for (const c of order) {
    if (g[0][c] !== 0) continue;
    best = Math.min(best, search(place(g, c, 1), depth - 1, alpha, beta, true));
    beta = Math.min(beta, best);
    if (alpha >= beta) break;
  }
  return best;
}

function bestColumn(g: Grid): number {
  const order = [3, 2, 4, 1, 5, 0, 6];
  let best = -Infinity;
  let pick = -1;
  for (const c of order) {
    if (g[0][c] !== 0) continue;
    const score = search(place(g, c, 2), 4, -Infinity, Infinity, false);
    if (score > best) {
      best = score;
      pick = c;
    }
  }
  return pick;
}

export default function ConnectFour() {
  const [grid, setGrid] = useState<Grid>(empty);
  const [turn, setTurn] = useState<1 | 2>(1);
  const [thinking, setThinking] = useState(false);
  const [score, setScore] = useState({ win: 0, loss: 0, draw: 0 });

  const line = useMemo(() => winLine(grid), [grid]);
  const full = grid[0].every((v) => v !== 0);
  const over = Boolean(line) || full;

  useEffect(() => {
    if (over || turn !== 2) return;
    setThinking(true);
    const timer = window.setTimeout(() => {
      const col = bestColumn(grid);
      const next = place(grid, col === -1 ? 3 : col, 2);
      setGrid(next);
      const won = winLine(next);
      if (won) setScore((s) => ({ ...s, loss: s.loss + 1 }));
      else if (next[0].every((v) => v !== 0)) setScore((s) => ({ ...s, draw: s.draw + 1 }));
      setTurn(1);
      setThinking(false);
    }, 380);
    return () => window.clearTimeout(timer);
  }, [turn, grid, over]);

  const drop = (col: number) => {
    if (over || turn !== 1 || thinking) return;
    if (landing(grid, col) < 0) return;
    const next = place(grid, col, 1);
    setGrid(next);
    const won = winLine(next);
    if (won) {
      setScore((s) => ({ ...s, win: s.win + 1 }));
      return;
    }
    if (next[0].every((v) => v !== 0)) {
      setScore((s) => ({ ...s, draw: s.draw + 1 }));
      return;
    }
    setTurn(2);
  };

  const status = line
    ? grid[line[0][0]][line[0][1]] === 1
      ? 'You win!'
      : 'Computer wins.'
    : full
      ? 'Board full — draw.'
      : thinking
        ? 'Computer is thinking…'
        : 'Your turn — drop a red disc.';

  return (
    <div className="game">
      <div className="game-top">
        <div>
          <h3>Connect Four</h3>
          <p className="game-sub">Seven columns, four in a row. Red is you, yellow is the computer.</p>
        </div>
        <div className="scoreline">
          <span>W {score.win}</span>
          <span>D {score.draw}</span>
          <span>L {score.loss}</span>
        </div>
      </div>

      <div className="c4-wrap">
        <div className="c4-cols">
          {Array.from({ length: COLS }, (_, c) => (
            <button
              key={c}
              type="button"
              className="c4-drop"
              onClick={() => drop(c)}
              disabled={over || turn !== 1 || landing(grid, c) < 0}
              aria-label={`Drop in column ${c + 1}`}
            >
              ▾
            </button>
          ))}
        </div>
        <div className="c4-board">
          {grid.map((row, r) =>
            row.map((cell, c) => {
              const winning = line?.some(([lr, lc]) => lr === r && lc === c);
              return (
                <div
                  key={`${r}-${c}`}
                  className={`c4-cell${cell === 1 ? ' p1' : cell === 2 ? ' p2' : ''}${winning ? ' win' : ''}`}
                />
              );
            }),
          )}
        </div>
      </div>

      <div className="game-foot">
        <span className="game-status">{status}</span>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => {
            setGrid(empty());
            setTurn(1);
            setThinking(false);
          }}
        >
          {over ? 'Play again' : 'Reset'}
        </button>
      </div>
    </div>
  );
}
