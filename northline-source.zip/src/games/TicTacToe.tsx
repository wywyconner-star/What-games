import { useMemo, useState } from 'react';

type Cell = '' | 'X' | 'O';
const LINES = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

function findWinner(board: Cell[]): Cell | 'draw' | null {
  for (const [a, b, c] of LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(Boolean) ? 'draw' : null;
}

function minimax(board: Cell[], player: Cell, depth: number): number {
  const result = findWinner(board);
  if (result === 'O') return 10 - depth;
  if (result === 'X') return depth - 10;
  if (result === 'draw') return 0;

  const scores: number[] = [];
  for (let i = 0; i < 9; i++) {
    if (board[i]) continue;
    const next = [...board];
    next[i] = player;
    scores.push(minimax(next, player === 'O' ? 'X' : 'O', depth + 1));
  }
  return player === 'O' ? Math.max(...scores) : Math.min(...scores);
}

function aiMove(board: Cell[]): number {
  let best = -Infinity;
  let choice = -1;
  for (let i = 0; i < 9; i++) {
    if (board[i]) continue;
    const next = [...board];
    next[i] = 'O';
    const score = minimax(next, 'X', 1);
    if (score > best) {
      best = score;
      choice = i;
    }
  }
  return choice;
}

export default function TicTacToe() {
  const [board, setBoard] = useState<Cell[]>(Array(9).fill(''));
  const [thinking, setThinking] = useState(false);
  const [tally, setTally] = useState({ win: 0, loss: 0, draw: 0 });

  const winner = useMemo(() => findWinner(board), [board]);
  const over = winner !== null;

  const play = (index: number) => {
    if (board[index] || over || thinking) return;
    const next = [...board];
    next[index] = 'X';
    setBoard(next);

    const result = findWinner(next);
    if (result === 'X') setTally((t) => ({ ...t, win: t.win + 1 }));
    if (result === 'draw') setTally((t) => ({ ...t, draw: t.draw + 1 }));
    if (result) return;

    setThinking(true);
    window.setTimeout(() => {
      const move = aiMove(next);
      if (move >= 0) {
        const after = [...next];
        after[move] = 'O';
        setBoard(after);
        const aiResult = findWinner(after);
        if (aiResult === 'O') setTally((t) => ({ ...t, loss: t.loss + 1 }));
        if (aiResult === 'draw') setTally((t) => ({ ...t, draw: t.draw + 1 }));
      }
      setThinking(false);
    }, 320);
  };

  const status =
    winner === 'X'
      ? 'You win.'
      : winner === 'O'
        ? 'Computer wins.'
        : winner === 'draw'
          ? 'Draw.'
          : thinking
            ? 'Computer is thinking…'
            : 'Your move — you are X.';

  return (
    <div className="game">
      <div className="game-top">
        <div>
          <h3>Tic-Tac-Toe</h3>
          <p className="game-sub">
            3×3, X goes first. The computer plays a perfect game, so a draw is a good result.
          </p>
        </div>
        <div className="scoreline">
          <span>W {tally.win}</span>
          <span>D {tally.draw}</span>
          <span>L {tally.loss}</span>
        </div>
      </div>

      <div className="ttt-grid">
        {board.map((cell, i) => (
          <button
            key={i}
            type="button"
            className={`ttt-cell${cell ? ` filled ${cell === 'X' ? 'x' : 'o'}` : ''}`}
            onClick={() => play(i)}
            aria-label={`Square ${i + 1}${cell ? `, ${cell}` : ''}`}
          >
            {cell}
          </button>
        ))}
      </div>

      <div className="game-foot">
        <span className={`game-status${winner === 'X' ? ' good' : ''}`}>{status}</span>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => {
            setBoard(Array(9).fill(''));
            setThinking(false);
          }}
        >
          {over ? 'Play again' : 'Reset'}
        </button>
      </div>
    </div>
  );
}
