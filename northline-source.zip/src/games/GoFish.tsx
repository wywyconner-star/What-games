import { useEffect, useRef, useState } from 'react';

type PlayerState = { name: string; hand: number[]; books: number; human: boolean };
type State = {
  players: PlayerState[];
  deck: number[];
  turn: number;
  log: string[];
  over: boolean;
};

const RANK_LABEL = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const rankName = (r: number) => RANK_LABEL[r] ?? String(r);

function buildDeck(): number[] {
  const deck: number[] = [];
  for (let rank = 1; rank <= 13; rank++) for (let i = 0; i < 4; i++) deck.push(rank);
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function deal(deck: number[], count: number): { hand: number[]; deck: number[] } {
  const copy = [...deck];
  const hand = copy.splice(-count, count);
  return { hand, deck: copy };
}

function startGame(opponents: number): State {
  let deck = buildDeck();
  const players: PlayerState[] = [{ name: 'You', hand: [], books: 0, human: true }];
  const names = ['Maya', 'Jordan', 'Riley'];
  for (let i = 0; i < opponents; i++) {
    players.push({ name: names[i], hand: [], books: 0, human: false });
  }
  for (const player of players) {
    const dealt = deal(deck, 5);
    player.hand = dealt.hand;
    deck = dealt.deck;
  }
  return { players, deck, turn: 0, log: ['New deal — you go first.'], over: false };
}

function collectBooks(players: PlayerState[], log: string[]): void {
  for (const player of players) {
    for (let rank = 1; rank <= 13; rank++) {
      const matching = player.hand.filter((r) => r === rank).length;
      if (matching === 4) {
        player.hand = player.hand.filter((r) => r !== rank);
        player.books += 1;
        log.unshift(`${player.name} completed a book of ${rankName(rank)}s.`);
      }
    }
  }
}

function isOver(state: State): boolean {
  return state.players.every((p) => p.hand.length === 0);
}

function ask(state: State, targetIndex: number, rank: number): State {
  const players = state.players.map((p) => ({ ...p, hand: [...p.hand] }));
  const deck = [...state.deck];
  const log = [...state.log];
  const asker = players[state.turn];
  const target = players[targetIndex];
  const matches = target.hand.filter((r) => r === rank);

  if (matches.length) {
    target.hand = target.hand.filter((r) => r !== rank);
    asker.hand = [...asker.hand, ...matches];
    log.unshift(
      `${asker.name} asked ${target.name} for ${rankName(rank)}s — got ${matches.length}.`,
    );
  } else {
    log.unshift(`${target.name} says “Go fish!”`);
    if (deck.length) {
      asker.hand.push(deck.pop()!);
      log.unshift(`${asker.name} drew a card.`);
    }
  }

  collectBooks(players, log);
  const next = {
    ...state,
    players,
    deck,
    log: log.slice(0, 14),
    turn: matches.length ? state.turn : (state.turn + 1) % players.length,
    over: false,
  };
  next.over = isOver(next);
  return next;
}

function aiTurn(state: State): State {
  const me = state.players[state.turn];
  if (!me.hand.length) {
    const next = { ...state, turn: (state.turn + 1) % state.players.length };
    if (next.turn === 0) return next;
    return aiTurn(next);
  }
  const counts = new Map<number, number>();
  for (const rank of me.hand) counts.set(rank, (counts.get(rank) ?? 0) + 1);
  const ranked = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  const rank = ranked[0][0];
  const others = state.players.map((_, i) => i).filter((i) => i !== state.turn);
  const target = others[Math.floor(Math.random() * others.length)];
  return ask(state, target, rank);
}

export default function GoFish() {
  const [state, setState] = useState<State>(() => startGame(2));
  const [rank, setRank] = useState<number | null>(null);
  const lastAi = useRef('');

  // An empty hand cannot ask, so the turn moves on automatically.
  useEffect(() => {
    if (state.over || state.turn !== 0 || state.players[0].hand.length > 0) return;
    const timer = window.setTimeout(() => {
      setState((prev) => {
        if (prev.over || prev.players[0].hand.length > 0) return prev;
        const next = { ...prev, turn: (prev.turn + 1) % prev.players.length };
        return { ...next, over: isOver(next) };
      });
    }, 700);
    return () => window.clearTimeout(timer);
  }, [state]);

  useEffect(() => {
    if (state.over || state.turn === 0) return;
    const key = `${state.turn}|${state.players.map((p) => p.hand.length + ':' + p.books).join(',')}|${state.deck.length}`;
    if (lastAi.current === key) return;
    lastAi.current = key;
    const timer = window.setTimeout(() => {
      setState((prev) => (prev.turn === 0 || prev.over ? prev : aiTurn(prev)));
    }, 700);
    return () => window.clearTimeout(timer);
  }, [state]);

  const handCounts = (hand: number[]) => {
    const map = new Map<number, number>();
    for (const r of hand) map.set(r, (map.get(r) ?? 0) + 1);
    return [...map.entries()].sort((a, b) => a[0] - b[0]);
  };

  const me = state.players[0];
  const askOpponent = (index: number) => {
    if (state.turn !== 0 || state.over || rank === null) return;
    setState((prev) => (prev.turn !== 0 ? prev : ask(prev, index, rank)));
    setRank(null);
  };

  const winner = state.over
    ? [...state.players].sort((a, b) => b.books - a.books)[0]
    : null;

  return (
    <div className="game">
      <div className="game-top">
        <div>
          <h3>Go Fish</h3>
          <p className="game-sub">
            Ask a friend for a rank you already hold. Four of a kind makes a book.
          </p>
        </div>
        <div className="scoreline">
          <span>Deck {state.deck.length}</span>
          <span>Books {me.books}</span>
        </div>
      </div>

      <div className="fish-opponents">
        {state.players.slice(1).map((player, i) => (
          <button
            key={player.name}
            type="button"
            className={`fish-opp${state.turn === i + 1 ? ' active' : ''}${rank !== null && state.turn === 0 ? ' ready' : ''}`}
            onClick={() => askOpponent(i + 1)}
            disabled={state.turn !== 0 || rank === null || state.over}
          >
            <strong>{player.name}</strong>
            <span>{player.hand.length} cards</span>
            <span>{player.books} books</span>
          </button>
        ))}
      </div>

      <p className="fish-hint">
        {state.over
          ? winner
            ? `${winner.name} win${winner.human ? '' : 's'} with ${winner.books} books.`
            : 'Game over.'
          : state.turn !== 0
            ? `${state.players[state.turn].name} is asking…`
            : rank === null
              ? 'Pick a rank from your hand, then tap a friend.'
              : `Asking for ${rankName(rank)}s — tap a friend above.`}
      </p>

      <div className="fish-hand">
        {handCounts(me.hand).map(([r, n]) => (
          <button
            key={r}
            type="button"
            className={`fish-card${rank === r ? ' selected' : ''}`}
            onClick={() => setRank(rank === r ? null : r)}
            disabled={state.turn !== 0 || state.over}
          >
            <span className="fish-rank">{rankName(r)}</span>
            <span className="fish-count">×{n}</span>
          </button>
        ))}
        {me.hand.length === 0 && <p className="fish-empty">Hand empty — books: {me.books}</p>}
      </div>

      <div className="fish-log">
        {state.log.slice(0, 6).map((line, i) => (
          <p key={i}>{line}</p>
        ))}
      </div>

      <div className="game-foot">
        <span className="game-status">
          Books — {state.players.map((p) => `${p.name}: ${p.books}`).join(' · ')}
        </span>
        <button
          type="button"
          className="btn btn-primary"
          onClick={() => {
            lastAi.current = '';
            setRank(null);
            setState(startGame(Math.max(1, state.players.length - 1)));
          }}
        >
          New deal
        </button>
      </div>
    </div>
  );
}
