import { useCallback, useEffect, useRef, useState } from 'react';

type Grid = number[][];

const SIZE = 4;
const BEST_KEY = 'northline.best2048';

function newGrid(): Grid {
  const grid: Grid = Array.from({ length: SIZE }, () => Array<number>(SIZE).fill(0));
  spawn(spawn(grid));
  return grid;
}

function spawn(grid: Grid): Grid {
  const holes: [number, number][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) if (grid[r][c] === 0) holes.push([r, c]);
  }
  if (!holes.length) return grid;
  const [r, c] = holes[Math.floor(Math.random() * holes.length)];
  grid[r][c] = Math.random() < 0.9 ? 2 : 4;
  return grid;
}

function slide(row: number[]): { row: number[]; gain: number } {
  const values = row.filter((v) => v !== 0);
  const out: number[] = [];
  let gain = 0;
  for (let i = 0; i < values.length; i++) {
    if (values[i] === values[i + 1]) {
      const merged = values[i] * 2;
      out.push(merged);
      gain += merged;
      i++;
    } else {
      out.push(values[i]);
    }
  }
  while (out.length < SIZE) out.push(0);
  return { row: out, gain };
}

const clone = (grid: Grid): Grid => grid.map((row) => row.slice());

function move(grid: Grid, dir: 'left' | 'right' | 'up' | 'down'): { grid: Grid; gain: number } {
  let work = clone(grid);
  let gain = 0;
  const horizontal = dir === 'left' || dir === 'right';
  const reverse = dir === 'right' || dir === 'down';

  const lines: number[][] = [];
  for (let i = 0; i < SIZE; i++) {
    const line = horizontal ? work[i].slice() : work.map((row) => row[i]);
    if (reverse) line.reverse();
    const result = slide(line);
    gain += result.gain;
    const final = result.row;
    if (reverse) final.reverse();
    lines.push(final);
  }

  work = Array.from({ length: SIZE }, () => Array<number>(SIZE).fill(0));
  for (let i = 0; i < SIZE; i++) {
    if (horizontal) work[i] = lines[i];
    else for (let j = 0; j < SIZE; j++) work[j][i] = lines[i][j];
  }
  return { grid: work, gain };
}

const same = (a: Grid, b: Grid) =>
  a.every((row, r) => row.every((v, c) => v === b[r][c]));

function canMove(grid: Grid): boolean {
  if (grid.some((row) => row.some((v) => v === 0))) return true;
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (c + 1 < SIZE && grid[r][c] === grid[r][c + 1]) return true;
      if (r + 1 < SIZE && grid[r][c] === grid[r + 1][c]) return true;
    }
  }
  return false;
}

export default function TwentyFortyEight() {
  const [grid, setGrid] = useState<Grid>(newGrid);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(() => Number(localStorage.getItem(BEST_KEY) ?? 0));
  const [status, setStatus] = useState<'playing' | 'won' | 'over'>('playing');
  const touch = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (score > best) {
      setBest(score);
      try {
        localStorage.setItem(BEST_KEY, String(score));
      } catch {
        /* ignore */
      }
    }
  }, [score, best]);

  const gridRef = useRef(grid);

  const play = useCallback(
    (dir: 'left' | 'right' | 'up' | 'down') => {
      const current = gridRef.current;
      const result = move(current, dir);
      if (same(result.grid, current)) return;
      const next = spawn(result.grid);
      gridRef.current = next;
      setGrid(next);
      setScore((s) => s + result.gain);
      if (result.grid.flat().includes(2048)) setStatus('won');
      else if (!canMove(next)) setStatus('over');
    },
    [],
  );

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const map: Record<string, 'left' | 'right' | 'up' | 'down'> = {
        ArrowLeft: 'left',
        ArrowRight: 'right',
        ArrowUp: 'up',
        ArrowDown: 'down',
        a: 'left',
        d: 'right',
        w: 'up',
        s: 'down',
      };
      const dir = map[event.key];
      if (!dir) return;
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;
      event.preventDefault();
      play(dir);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [play]);

  const reset = () => {
    const fresh = newGrid();
    gridRef.current = fresh;
    setGrid(fresh);
    setScore(0);
    setStatus('playing');
  };

  return (
    <div className="game">
      <div className="game-top">
        <div>
          <h3>2048</h3>
          <p className="game-sub">
            Merge matching tiles. Arrow keys or WASD; swipe on a phone.
          </p>
        </div>
        <div className="scoreline">
          <span>Score {score}</span>
          <span>Best {best}</span>
        </div>
      </div>

      <div
        className="g2048-board"
        onTouchStart={(e) => {
          const t = e.touches[0];
          touch.current = { x: t.clientX, y: t.clientY };
        }}
        onTouchEnd={(e) => {
          if (!touch.current) return;
          const t = e.changedTouches[0];
          const dx = t.clientX - touch.current.x;
          const dy = t.clientY - touch.current.y;
          if (Math.abs(dx) < 24 && Math.abs(dy) < 24) return;
          if (Math.abs(dx) > Math.abs(dy)) play(dx > 0 ? 'right' : 'left');
          else play(dy > 0 ? 'down' : 'up');
          touch.current = null;
        }}
      >
        {grid.map((row, r) =>
          row.map((value, c) => (
            <div key={`${r}-${c}`} className={`g2048-cell v${value}`}>
              {value || ''}
            </div>
          )),
        )}
      </div>

      <p className="game-status">
        {status === 'won'
          ? 'You reached 2048! Keep going for a higher score.'
          : status === 'over'
            ? 'No moves left — game over.'
            : 'Use the arrow keys or the buttons below.'}
      </p>

      <div className="dpad">
        <button type="button" onClick={() => play('up')} aria-label="Up">
          ↑
        </button>
        <div>
          <button type="button" onClick={() => play('left')} aria-label="Left">
            ←
          </button>
          <button type="button" onClick={() => play('down')} aria-label="Down">
            ↓
          </button>
          <button type="button" onClick={() => play('right')} aria-label="Right">
            →
          </button>
        </div>
      </div>

      <div className="game-foot">
        <span className="game-status">Score {score}</span>
        <button type="button" className="btn btn-primary" onClick={reset}>
          New game
        </button>
      </div>
    </div>
  );
}
