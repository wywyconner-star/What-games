import { useCallback, useEffect, useState } from 'react';
import { SettingsProvider, useSettings } from './lib/store';
import Portal from './components/Portal';
import Gate from './components/Gate';
import Shell from './components/Shell';

const SESSION_KEY = 'northline.unlocked';

function Root() {
  const { settings } = useSettings();
  const [view, setView] = useState<'portal' | 'app'>(() => {
    try {
      return sessionStorage.getItem(SESSION_KEY) === '1' ? 'app' : 'portal';
    } catch {
      return 'portal';
    }
  });
  const [gateOpen, setGateOpen] = useState(false);

  const panic = useCallback(() => {
    setGateOpen(false);
    setView('portal');
    try {
      sessionStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
    if (window.location.hash) {
      history.replaceState(null, '', window.location.pathname);
    }
  }, []);

  const unlock = useCallback(() => {
    try {
      sessionStorage.setItem(SESSION_KEY, '1');
    } catch {
      /* ignore */
    }
    setGateOpen(false);
    setView('app');
  }, []);

  // Panic key: instantly returns to the plain course portal.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const key = event.key;
      if (!key) return;
      const target = event.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable);

      if (settings.panicKey === 'Escape' && key === 'Escape') {
        panic();
        return;
      }
      if (settings.panicKey === 'Tab' && key === 'Tab' && !event.ctrlKey && !event.metaKey) {
        if (typing) return;
        event.preventDefault();
        panic();
        return;
      }
      if (key.toLowerCase() === settings.panicKey.toLowerCase() && settings.panicKey.length === 1) {
        if (typing) return;
        event.preventDefault();
        panic();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [settings.panicKey, panic]);

  return (
    <>
      {view === 'portal' ? <Portal onOpenGate={() => setGateOpen(true)} /> : <Shell onPanic={panic} />}
      <Gate open={gateOpen} onClose={() => setGateOpen(false)} onUnlock={unlock} />
    </>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <Root />
    </SettingsProvider>
  );
}
